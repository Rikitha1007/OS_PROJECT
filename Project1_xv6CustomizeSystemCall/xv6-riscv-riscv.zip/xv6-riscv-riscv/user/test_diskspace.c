#include "kernel/types.h"
#include "user.h"
#include "kernel/stat.h"

int main(void) {
    diskspace();
}